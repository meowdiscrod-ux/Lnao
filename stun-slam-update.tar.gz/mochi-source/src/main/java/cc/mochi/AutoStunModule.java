package cc.mochi;

import cc.mochi.event.impl.combat.MaceHitEvent;
import cc.mochi.event.impl.combat.TriggerBotReadyEvent;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Stun Slam: while falling, hit a blocking player with an axe to disable their shield,
 * confirm the stun, swap to the mace and smash. Replaces the old Auto Stun logic and the
 * Shield Slam mode that used to live inside Auto Mace.
 */
public class AutoStunModule extends Module implements AttackInputBlocker, PlayerStatusListener, AttackTargetBlocker {
   /** True while a stun slam sequence is running (read by Trigger Bot, Breach Swap and others). */
   public static boolean booleanState;

   private static final double MIN_SMASH_FALL = 1.5;

   private final DoubleSetting reachSetting;
   private final DoubleSetting aimRangeSetting;
   private final DoubleSetting fovSetting;
   private final ChoiceSetting aimModeSetting;
   private final DoubleSetting aimSpeedSetting;
   private final DoubleSetting minFallSetting;
   private final DoubleRangeSetting slamDelaySetting;
   private final DoubleSetting chanceSetting;
   private final DoubleSetting cooldownSetting;
   private final BooleanSetting swapBackSetting;

   private StunState state = StunState.IDLE;
   private PlayerEntity target;
   private UUID targetId;
   private int originalSlot = -1;
   private int axeSlot = -1;
   private int maceSlot = -1;
   private long stateSince;
   private long axeHitAt;
   private long confirmedAt;
   private long swapBackAt;
   private long cooldownUntil;
   private int delayTicks;
   private boolean confirmed;
   private boolean selfAttacking;
   private boolean rollPassed = true;
   private UUID rolledId;
   private AutoMaceModule autoMace;

   // written from the network thread by onPlayerStatus, read on the client thread
   private volatile UUID stunnedId;
   private volatile long stunnedAt;

   public AutoStunModule() {
      super("Stun Slam", "Axe-stuns a blocking target, then mace slams", ModuleCategory.COMBAT);

      this.reachSetting = new DoubleSetting("Reach", 2.5, 4.5, 3.0, 0.1);
      this.aimRangeSetting = new DoubleSetting("Aim Range", 2.0, 10.0, 5.0, 0.1);
      this.fovSetting = new DoubleSetting("FOV", 10.0, 360.0, 360.0, 1.0);
      String[] aimModes = new String[3];
      aimModes[0] = "Silent";
      aimModes[1] = "Normal";
      aimModes[2] = "None";
      this.aimModeSetting = new ChoiceSetting("Aim Mode", "Silent", aimModes);
      this.aimSpeedSetting = new DoubleSetting("Aim Speed", 1.0, 50.0, 10.0, 0.1);
      this.minFallSetting = new DoubleSetting("Min Fall Dist", 1.6, 10.0, 2.0, 0.1);
      this.slamDelaySetting = new DoubleRangeSetting("Slam Delay (Ticks)", 0.0, 10.0, 0.0, 1.0, 1.0);
      this.chanceSetting = new DoubleSetting("Stun Slam Chance (%)", 0.0, 100.0, 100.0, 1.0);
      this.cooldownSetting = new DoubleSetting("Cooldown (ms)", 0.0, 2000.0, 400.0, 10.0);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);

      this.addSetting(this.aimModeSetting);
      this.addSetting(this.aimRangeSetting);
      this.addSetting(this.aimSpeedSetting);
      this.addSetting(this.fovSetting);
      this.addSetting(this.reachSetting);
      this.addSetting(this.minFallSetting);
      this.addSetting(this.slamDelaySetting);
      this.addSetting(this.chanceSetting);
      this.addSetting(this.cooldownSetting);
      this.addSetting(this.swapBackSetting);
      this.aimRangeSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
      this.aimSpeedSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
      this.fovSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
   }

   // ------------------------------------------------------------------ lifecycle

   @Override
   public void onEnable() {
      this.resetState();
      this.cooldownUntil = 0L;
   }

   @Override
   public void onDisable() {
      this.abort(false);
      this.cooldownUntil = 0L;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent event) {
      this.resetState();
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent event) {
      if (event.getWorld() != mc.world) {
         this.resetState();
      }
   }

   // ------------------------------------------------------------------ integration hooks

   /** Called by Auto Mace: true when Stun Slam is going to deal with this shielding target itself. */
   public static boolean isHandlingShield(PlayerEntity player) {
      AutoStunModule module = (AutoStunModule)ModuleLookup.computeModuleForClass(AutoStunModule.class);
      return module != null && module.isEnabled() && module.canHandle(player);
   }

   public boolean returnFalse() {
      return false;
   }

   @EventHandler
   private void onTriggerBotReady(TriggerBotReadyEvent event) {
      if (this.isEnabled() && this.state != StunState.IDLE) {
         event.setCancelled(true);
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (this.isEnabled() && !this.selfAttacking) {
         return this.state == StunState.WAITING_ATTACK || this.state == StunState.WAITING_STUN;
      }

      return false;
   }

   @Override
   public boolean shouldBlockAttackTarget(Entity entity) {
      return this.isEnabled() && this.state != StunState.IDLE && entity != null && entity == this.target;
   }

   /** Entity status 30 = shield broke / disabled. This is the server's confirmation that the stun landed. */
   @Override
   public void onPlayerStatus(PlayerEntity player) {
      if (player != null) {
         this.stunnedId = player.getUuid();
         this.stunnedAt = System.currentTimeMillis();
      }
   }

   // ------------------------------------------------------------------ main loop

   @EventHandler
   private void onTick(TickEvent event) {
      if (mc.player == null || mc.world == null || mc.currentScreen != null || !mc.player.isAlive()) {
         this.abort(true);
         return;
      }

      long now = System.currentTimeMillis();
      switch (this.state) {
         case IDLE:
            this.tickIdle(now);
            break;
         case WAITING_ATTACK:
            if (this.validateTarget()) {
               this.tickAxeHit(now);
            } else {
               this.abort(true);
            }
            break;
         case WAITING_STUN:
            if (this.validateTarget()) {
               this.tickStun(now);
            } else {
               this.abort(true);
            }
            break;
         case WAITING_SWAP_BACK:
            this.tickSwapBack(now);
            break;
      }

      booleanState = this.state != StunState.IDLE;
   }

   private void tickIdle(long now) {
      if (now < this.cooldownUntil || !this.canEngage()) {
         this.releaseAim();
         this.dropTarget();
         return;
      }

      PlayerEntity best = this.pickTarget();
      if (best == null) {
         this.releaseAim();
         this.dropTarget();
         return;
      }

      this.target = best;
      this.targetId = best.getUuid();

      if (!this.isRolledIn(best)) {
         this.releaseAim();
         return;
      }

      if (!this.canHandle(best)) {
         this.releaseAim();
         return;
      }

      this.aimAt(best);

      if (this.withinReach(best) && this.isAimedAt(best)) {
         int axe = this.findAxeSlot();
         int mace = this.findMaceSlot();
         if (axe < 0 || mace < 0) {
            return;
         }

         if (!CombatActionCoordinator.testCombatActionOwner(CombatActionOwner.AUTOSHIELDBREAK)) {
            return;
         }

         this.originalSlot = mc.player.getInventory().getSelectedSlot();
         this.axeSlot = axe;
         this.maceSlot = mace;
         this.confirmed = false;
         this.stateSince = now;
         this.state = StunState.WAITING_ATTACK;
         booleanState = true;
         this.tickAxeHit(now);
      }
   }

   private void tickAxeHit(long now) {
      if (now - this.stateSince > 450L || !this.fallingEnough(true)) {
         this.abort(true);
         return;
      }

      this.aimAt(this.target);
      if (!this.withinReach(this.target) || !this.isAimedAt(this.target)) {
         return;
      }

      if (!this.isBlockingFront(this.target)) {
         // shield already down or we are outside its arc - nothing to stun, let normal combat take over
         this.abort(true);
         return;
      }

      if (mc.player.isUsingItem()) {
         return;
      }

      this.selectSlot(this.axeSlot);
      if (this.attack()) {
         this.axeHitAt = System.currentTimeMillis();
         this.stateSince = this.axeHitAt;
         this.confirmed = false;
         this.state = StunState.WAITING_STUN;
      }
   }

   private void tickStun(long now) {
      this.aimAt(this.target);

      if (!this.confirmed) {
         boolean statusSeen = this.targetId != null && this.targetId.equals(this.stunnedId) && this.stunnedAt >= this.axeHitAt;
         if (statusSeen || !this.isBlockingFront(this.target)) {
            this.confirmed = true;
            this.confirmedAt = now;
            this.delayTicks = this.rollDelayTicks();
         } else if (now - this.axeHitAt > 350L) {
            // axe did not break the shield - do not waste the mace
            this.cooldownUntil = now + (long)this.cooldownSetting.getValue();
            this.abort(true);
            return;
         } else {
            return;
         }
      }

      if (this.delayTicks > 0) {
         this.delayTicks--;
         return;
      }

      if (now - this.confirmedAt > 450L || !this.fallingEnough(false)) {
         this.cooldownUntil = now + (long)this.cooldownSetting.getValue();
         this.abort(true);
         return;
      }

      if (!this.withinReach(this.target) || !this.isAimedAt(this.target)) {
         return;
      }

      this.selectSlot(this.maceSlot);
      if (this.attack()) {
         MochiClient.INSTANCE.getMochiEventBus().post(new MaceHitEvent());
         this.cooldownUntil = System.currentTimeMillis() + (long)this.cooldownSetting.getValue();
         this.swapBackAt = System.currentTimeMillis() + this.randomMs(15.0, 60.0);
         this.releaseAim();
         this.state = StunState.WAITING_SWAP_BACK;
      }
   }

   private void tickSwapBack(long now) {
      if (now < this.swapBackAt) {
         return;
      }

      if (this.swapBackSetting.isOn()) {
         this.restoreSlot();
      }

      this.finish();
   }

   // ------------------------------------------------------------------ conditions

   private boolean canEngage() {
      if (!this.fallingEnough(true) || mc.player.isUsingItem()) {
         return false;
      }

      if (CombatActionCoordinator.checkCondition()) {
         return false;
      }

      if (this.autoMace == null) {
         Module module = ModuleLookup.computeModuleForClass(AutoMaceModule.class);
         if (module instanceof AutoMaceModule) {
            this.autoMace = (AutoMaceModule)module;
         }
      }

      if (this.autoMace != null && this.autoMace.isEnabled() && AutoMaceModule.getSelectedSlot2(this.autoMace) != -1) {
         return false;
      }

      return true;
   }

   /** Player must be airborne, falling and (for the smash) above the minimum fall distance. */
   private boolean fallingEnough(boolean forAxe) {
      if (mc.player.isOnGround() || mc.player.isGliding()) {
         return false;
      }

      if (mc.player.getVelocity().y > -1.0E-4) {
         return false;
      }

      double fall = (double)mc.player.fallDistance;
      double need = forAxe ? Math.max(this.minFallSetting.getValue(), MIN_SMASH_FALL + 0.05) : MIN_SMASH_FALL + 0.05;
      return fall >= need;
   }

   private boolean canHandle(PlayerEntity player) {
      return player != null && mc.player != null && this.isBlockingFront(player) && this.findAxeSlot() >= 0 && this.findMaceSlot() >= 0;
   }

   /** Target must be actively blocking (past the 5 tick warm up) and we must stand inside the shield arc. */
   private boolean isBlockingFront(PlayerEntity player) {
      if (player == null || !player.isUsingItem() || !(player.getActiveItem().getItem() instanceof ShieldItem) || !player.isBlocking()) {
         return false;
      }

      double dx = mc.player.getX() - player.getX();
      double dz = mc.player.getZ() - player.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 1.0E-4) {
         return true;
      }

      float yaw = (float)Math.toRadians((double)player.getYaw());
      double dot = -Math.sin((double)yaw) * dx / len + Math.cos((double)yaw) * dz / len;
      return dot > 0.15;
   }

   private boolean validTarget(PlayerEntity player) {
      if (player == null || player == mc.player || !player.isAlive() || player.isRemoved() || player.isSpectator()) {
         return false;
      }

      return !FriendManager.testPlayerEntity(player);
   }

   private boolean validateTarget() {
      PlayerEntity player = this.target;
      if (!this.validTarget(player) || !mc.player.canSee(player)) {
         return false;
      }

      return this.eyeDistanceSq(player) <= (this.reachSetting.getValue() + 1.5) * (this.reachSetting.getValue() + 1.5);
   }

   private boolean withinReach(PlayerEntity player) {
      double reach = this.reachSetting.getValue();
      return mc.player.canSee(player) && this.eyeDistanceSq(player) <= reach * reach;
   }

   private double eyeDistanceSq(Entity entity) {
      Vec3d eye = mc.player.getEyePos();
      Box box = entity.getBoundingBox();
      double x = MathHelper.clamp(eye.x, box.minX, box.maxX);
      double y = MathHelper.clamp(eye.y, box.minY, box.maxY);
      double z = MathHelper.clamp(eye.z, box.minZ, box.maxZ);
      return eye.squaredDistanceTo(x, y, z);
   }

   // ------------------------------------------------------------------ targeting

   private PlayerEntity pickTarget() {
      double range = this.aimRangeSetting.getValue();
      double rangeSq = range * range;
      double halfFov = this.fovSetting.getValue() / 2.0;
      PlayerEntity best = null;
      double bestScore = Double.MAX_VALUE;

      for (PlayerEntity player : mc.world.getPlayers()) {
         if (!this.validTarget(player)) {
            continue;
         }

         double distSq = mc.player.squaredDistanceTo(player);
         if (distSq > rangeSq || !this.inFov(player, halfFov)) {
            continue;
         }

         double score = distSq;
         if (this.isBlockingFront(player)) {
            score *= 0.25;
         }

         if (this.targetId != null && this.targetId.equals(player.getUuid())) {
            score *= 0.7;
         }

         if (score < bestScore) {
            bestScore = score;
            best = player;
         }
      }

      return best;
   }

   private boolean inFov(Entity entity, double halfFov) {
      if (halfFov >= 180.0) {
         return true;
      }

      Vec3d eye = mc.player.getEyePos();
      Vec3d center = entity.getBoundingBox().getCenter();
      double dx = center.x - eye.x;
      double dz = center.z - eye.z;
      if (dx * dx + dz * dz <= 1.0E-6) {
         return true;
      }

      float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      return (double)Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - yaw)) <= halfFov;
   }

   private boolean isRolledIn(PlayerEntity player) {
      UUID id = player.getUuid();
      if (!id.equals(this.rolledId)) {
         this.rolledId = id;
         this.rollPassed = ThreadLocalRandom.current().nextDouble() * 100.0 < this.chanceSetting.getValue();
      }

      return this.rollPassed;
   }

   private void dropTarget() {
      this.target = null;
      this.targetId = null;
   }

   // ------------------------------------------------------------------ rotation

   private boolean aimEnabled() {
      return !this.aimModeSetting.getSelected().equals("None");
   }

   private void aimAt(PlayerEntity player) {
      if (!this.aimEnabled() || player == null) {
         return;
      }

      boolean silent = this.aimModeSetting.getSelected().equals("Silent");
      double speed = this.aimSpeedSetting.getValue() * 60.0;
      double smoothing = 0.45;
      if (silent) {
         speed *= 1.5;
         smoothing = 0.75;
      }

      RotationProfile profile = RotationProfile.createRotationProfile().withMaxRotationSpeed(speed).computeRotationProfile10(smoothing).computeRotationProfile3(0.3).withSilentAim(silent).computeRotationProfile2(false);
      Supplier<Vec3d> supplier = () -> this.aimPoint();
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, supplier, profile);
   }

   private Vec3d aimPoint() {
      PlayerEntity player = this.target;
      if (player == null) {
         return null;
      }

      Box box = player.getBoundingBox();
      Vec3d center = box.getCenter();
      return new Vec3d(center.x, box.minY + (double)player.getHeight() * 0.65, center.z);
   }

   private void releaseAim() {
      RotationManager.updateState9(this);
   }

   /** Uses the same rotation the attack will be sent with, so silent aim is checked correctly. */
   private boolean isAimedAt(PlayerEntity player) {
      if (player == null) {
         return false;
      }

      HitResult hit = BlockInteractUtils.computeHitResult(RotationManager.computeFloat2(), RotationManager.computeFloat7(), this.reachSetting.getValue() + 0.5);
      return hit instanceof EntityHitResult && ((EntityHitResult)hit).getEntity() == player;
   }

   // ------------------------------------------------------------------ actions

   private boolean attack() {
      this.selfAttacking = true;
      try {
         return AttackActions.testMinecraftClient(mc, "combat.attack.stunslam");
      } finally {
         this.selfAttacking = false;
      }
   }

   private void selectSlot(int slot) {
      if (slot >= 0 && slot <= 8 && mc.player.getInventory().getSelectedSlot() != slot) {
         mc.player.getInventory().setSelectedSlot(slot);
      }
   }

   private void restoreSlot() {
      if (mc.player != null && this.originalSlot >= 0 && this.originalSlot <= 8) {
         mc.player.getInventory().setSelectedSlot(this.originalSlot);
      }
   }

   /** Ends a sequence early. Always puts the hotbar back where it was when we changed it. */
   private void abort(boolean restore) {
      if (this.state != StunState.IDLE && restore) {
         this.restoreSlot();
      }

      this.releaseAim();
      this.finish();
   }

   private void finish() {
      CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.AUTOSHIELDBREAK);
      this.resetState();
   }

   private void resetState() {
      this.state = StunState.IDLE;
      this.target = null;
      this.targetId = null;
      this.originalSlot = -1;
      this.axeSlot = -1;
      this.maceSlot = -1;
      this.confirmed = false;
      this.delayTicks = 0;
      this.selfAttacking = false;
      this.rolledId = null;
      this.rollPassed = true;
      booleanState = false;
   }

   private int rollDelayTicks() {
      int low = (int)Math.round(this.slamDelaySetting.getLowerValue2());
      int high = (int)Math.round(this.slamDelaySetting.getUpperValue3());
      if (high <= low) {
         return Math.max(0, low);
      }

      return low + ThreadLocalRandom.current().nextInt(high - low + 1);
   }

   private long randomMs(double low, double high) {
      return Math.round(low + (high - low) * ThreadLocalRandom.current().nextDouble());
   }

   // ------------------------------------------------------------------ inventory

   private int findAxeSlot() {
      for (int slot = 0; slot < 9; slot++) {
         ItemStack stack = mc.player.getInventory().getStack(slot);
         if (stack.getItem() instanceof AxeItem || stack.isIn(ItemTags.AXES)) {
            return slot;
         }
      }

      return -1;
   }

   /** Picks the mace with the highest Density level (first one on ties). */
   private int findMaceSlot() {
      int bestSlot = -1;
      int bestDensity = -1;
      for (int slot = 0; slot < 9; slot++) {
         ItemStack stack = mc.player.getInventory().getStack(slot);
         if (stack.getItem() instanceof MaceItem) {
            int density = this.densityLevel(stack);
            if (density > bestDensity) {
               bestDensity = density;
               bestSlot = slot;
            }
         }
      }

      return bestSlot;
   }

   private int densityLevel(ItemStack stack) {
      if (stack.isEmpty()) {
         return 0;
      }

      ItemEnchantmentsComponent enchantments = (ItemEnchantmentsComponent)stack.get(MinecraftClientAccess38.getENCHANTMENTS());
      if (enchantments == null) {
         return 0;
      }

      for (RegistryEntry entry : enchantments.getEnchantments()) {
         if (entry.getKey().isPresent() && ((RegistryKey)entry.getKey().get()).getValue().getPath().contains("density")) {
            return enchantments.getLevel(entry);
         }
      }

      return 0;
   }
}
